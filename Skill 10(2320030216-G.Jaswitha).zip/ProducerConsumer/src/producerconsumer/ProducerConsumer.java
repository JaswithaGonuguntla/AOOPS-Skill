package producerconsumer;

import java.util.LinkedList;
import java.util.Queue;

// Shared buffer between Producer and Consumer
class MessageQueue {
    private Queue<String> queue = new LinkedList<>();
    private final int CAPACITY = 5;

    // Produce method (adds messages)
    public synchronized void produce(String message) throws InterruptedException {
        while (queue.size() == CAPACITY) {
            System.out.println("Queue is full. Producer is waiting...");
            wait(); // Wait if queue is full
        }
        queue.add(message);
        System.out.println("Produced: " + message);
        notify(); // Notify consumer that an item is available
    }

    // Consume method (removes messages)
    public synchronized String consume() throws InterruptedException {
        while (queue.isEmpty()) {
            System.out.println("Queue is empty. Consumer is waiting...");
            wait(); // Wait if queue is empty
        }
        String message = queue.poll();
        System.out.println("Consumed: " + message);
        notify(); // Notify producer that space is available
        return message;
    }
}

// Producer class
class Producer extends Thread {
    private MessageQueue messageQueue;

    public Producer(MessageQueue queue) {
        this.messageQueue = queue;
    }

    @Override
    public void run() {
        int messageNumber = 1;
        try {
            while (true) {
                String message = "Message " + messageNumber++;
                messageQueue.produce(message);
                Thread.sleep(500); // Simulating processing time
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

// Consumer class
class Consumer extends Thread {
    private MessageQueue messageQueue;

    public Consumer(MessageQueue queue) {
        this.messageQueue = queue;
    }

    @Override
    public void run() {
        try {
            while (true) {
                messageQueue.consume();
                Thread.sleep(1000); // Simulating processing time
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

// Main class
public class ProducerConsumer {
    public static void main(String[] args) {
        MessageQueue messageQueue = new MessageQueue();

        // Create producer and consumer threads
        Producer producer = new Producer(messageQueue);
        Consumer consumer = new Consumer(messageQueue);

        // Start both threads
        producer.start();
        consumer.start();
    }
}
